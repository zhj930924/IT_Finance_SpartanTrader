﻿Module ProcessAutomation

    Public Sub WarmStart()
        CreateAndConnectTheADOObjects()
        If OpenDBConnection() = False Then
            Exit Sub ' because it could not connect
        End If
    End Sub

    Public Sub stStart()
        ' Turn off formular bar to create more space
        Globals.ThisWorkbook.Application.DisplayFormulaBar = False
        ' Show the dashboard to us
        Globals.Dashboard.Activate()
        ' Click the beta button in the ribbon
        Globals.Ribbons.stRibbon.BetaBtn_Click(Nothing, Nothing)
    End Sub

    Public Sub stQuit()
        Globals.ThisWorkbook.Application.DisplayAlerts = False
        Globals.ThisWorkbook.Application.DisplayFormulaBar = True
        Globals.ThisWorkbook.Application.Quit()
    End Sub

End Module
