﻿Module stGlobals

    Public activeDB As String = ""
    Public teamID As String = "30"
    Public portfolioTableName As String = "PortfolioTeam" + teamID

End Module
