﻿Module stGlobals

    Public initialCAccount As Double = 0
    Public iRate As Double = 0
    Public startDate As Date
    Public currentDate As Date
    Public endDate As Date
    Public maxMargins As Double = 0
    Public TPVatStart As Double = 0
    Public IP As Double = 0

    ' ---------- homework 13 --------------------------------------
    Public activeDB As String = ""
    Public teamID As String = "30"
    Public portfolioTableName As String = "PortfolioTeam" + teamID

End Module
