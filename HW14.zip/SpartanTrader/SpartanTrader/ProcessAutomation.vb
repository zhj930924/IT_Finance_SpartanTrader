﻿Module ProcessAutomation

    Public Sub WarmStart()
        ClearOldDataInListObjects() 'new line
        CreateAndConnectTheADOObjects()
        If OpenDBConnection() = False Then
            Exit Sub ' because it could not connect
        End If
        DownloadStaticData()
        currentDate = DownloadCurrentDate()
        DownloadPricesForOneDay(currentDate)
        CalcAndDisplayFinancialMetrics(currentDate)
    End Sub

    Public Sub ClearOldDataInListObjects()

        Globals.Markets.StockMarketLO.DataSource = Nothing
        Globals.Markets.OptionMarketLO.DataSource = Nothing
        Globals.Markets.SP500LO.DataSource = Nothing
        Globals.Portfolio.InitialPositionsLO.DataSource = Nothing
        Globals.Portfolio.AcquiredPositionsLO.DataSource = Nothing
        Globals.Environment.SettingsLO.DataSource = Nothing
        Globals.Environment.TransactionCostsLO.DataSource = Nothing

    End Sub

    Public Sub DownloadStaticData()

        DownloadInitialPositions()
        DownloadTransactionCosts()
        DownloadEnvironmentVariable()
        DownloadTickers()
        ' we use 'get' to indicate that we are exracting data from the dataset, and 'download'
        ' to indicate that we are extracting data from the database
        initialCAccount = GetInitialCAccount()
        iRate = GetIRate()
        startDate = GetStartDate()
        endDate = GetEndDate()
        maxMargins = GetMaxMargins()
        TPVatStart = CalcTPVAtStart()

    End Sub

    Public Sub CalcAndDisplayFinancialMetrics(targetDate As Date)

        Globals.Dashboard.maxMarginCell.Value = maxMargins
        Globals.Dashboard.TPVatStartCell.Value = TPVatStart
        IP = CalcIPValue(targetDate)
        Globals.Dashboard.IPCell.Value = IP

    End Sub

    Public Sub stStart()
        ' Turn off formular bar to create more space
        Globals.ThisWorkbook.Application.DisplayFormulaBar = False
        ' Show the dashboard to us
        Globals.Dashboard.Activate()
        ' Click the beta button in the ribbon
        Globals.Ribbons.stRibbon.BetaBtn_Click(Nothing, Nothing)
    End Sub

    Public Sub stQuit()
        Globals.ThisWorkbook.Application.DisplayAlerts = False
        Globals.ThisWorkbook.Application.DisplayFormulaBar = True
        Globals.ThisWorkbook.Application.Quit()
    End Sub

End Module
