﻿Module PortfolioManagement

    Public Function CalcTPVAtStart() As Double

        Return CalcIPValue(startDate) + initialCAccount

    End Function

    Public Function CalcIPValue(targetDate As Date) As Double

        Dim tempCumulativeValue As Double = 0
        Dim tempSymbol As String
        Dim tempUnits As Double

        If myDataSet.Tables.Contains("InitialPositionTable") Then
            For Each myRow As DataRow In myDataSet.Tables("InitialPositionTable").Rows
                tempSymbol = myRow("Symbol").ToString.Trim
                tempUnits = myRow("Units")
                tempCumulativeValue = tempCumulativeValue + (tempUnits * CalcMTM(tempSymbol, targetDate))
            Next
        End If

        Return tempCumulativeValue

    End Function

    Public Function CalcMTM(symbol As String, targetDate As Date) As Double

        Return (GetAsk(symbol, targetDate) + GetBid(symbol, targetDate)) / 2

    End Function

    Public Function IsAStock(Symbol As String) As Boolean

        Symbol = Symbol.Trim()
        For Each myRow As DataRow In myDataSet.Tables("TickerTable").Rows
            If myRow("Ticker").trim() = Symbol Then
                Return True
            End If
        Next
        Return False

    End Function

End Module
