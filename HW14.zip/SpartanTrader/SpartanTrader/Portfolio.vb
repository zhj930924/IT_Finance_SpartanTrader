﻿
Public Class Portfolio

    Private Sub Sheet4_Startup() Handles Me.Startup

    End Sub

    Private Sub Sheet4_Shutdown() Handles Me.Shutdown

    End Sub

End Class
