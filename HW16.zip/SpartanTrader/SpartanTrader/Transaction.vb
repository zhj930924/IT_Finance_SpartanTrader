﻿Public Class Transaction

    Public price As Double = 0
    Public action As String = ""
    Public symbol As String = ""
    Public typeOfSecurity As String = ""
    Public qty As Double = 0
    Public transCost As Double = 0
    Public totValue As Double = 0
    Public typeOfPrice As String = "" 'Bid, Ask
    Public optionType As String = "" 'Call or Put
    Public delta As Double = 0
    Public strike As Double = 0


    Public Sub Clear()

    End Sub

    Public Function IsStockInputValid() As Boolean

        'Check ticker
        If Globals.Dashboard.TickerCBox.SelectedItem = Nothing Then
            MessageBox.Show("Picking stocks is hard, I know. Do your best, Dave.",
                            "No ticker", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        Else
            symbol = Globals.Dashboard.TickerCBox.SelectedItem
        End If

        'Check type
        If action = "" Then
            MessageBox.Show("To buy or not to buy, that is the question.",
                            "No transaction type", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If

        'qty
        Try
            qty = Integer.Parse(Globals.Dashboard.StockQtyTBox.Text)
        Catch
            MessageBox.Show("Quantity, Dave?",
                            "No quantity", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End Try
        Return True 'if all checks are passed

    End Function

    Public Sub ComputeStockTransactionProperties()

        Select Case typeOfPrice
            Case "Bid"
                price = GetBid(symbol, currentDate)
            Case "Ask"
                price = GetAsk(symbol, currentDate)
            Case Else
                price = 0
        End Select
        transCost = CalcTransCost()
        totValue = CalcTotValue()

    End Sub

    Public Sub DisplayTransactionData()

        Try
            Globals.Dashboard.PriceCell.Value = price
            Globals.Dashboard.TypeCell.Value = action
            Globals.Dashboard.SymbolCell.Value = symbol
            Globals.Dashboard.QtyCell.Value = qty
            Globals.Dashboard.TransCostCell.Value = transCost
            Globals.Dashboard.TotValueCell.Value = totValue
            Globals.Dashboard.InterestSLTCell.Value = interestSLT
            Globals.Dashboard.DeltaCell.Value = delta
        Catch
            'skip
        End Try

    End Sub

    Public Function CalcTransCost() As Double

        Return GetTCostCoefficient(symbol, action) * Math.Abs(qty) * price

    End Function

    Public Function CalcTotValue() As Double

        Select Case action
            Case "Buy"
                Return -(price * qty) - transCost
            Case "Sell"
                Return (price * qty) - transCost
            Case "SellShort"
                Return (price * qty) - transCost
            Case "CashDiv"
                Return (price * qty) - transCost
            Case "X-Put"
                Return (price * qty) - transCost
            Case "X-Call"
                Return -(price * qty) - transCost
            Case Else
                Return 0
        End Select

    End Function

End Class
