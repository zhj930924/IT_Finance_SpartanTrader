﻿
Public Class ThisWorkbook

    Private Sub ThisWorkbook_Startup() Handles Me.Startup
        ' This is where it all begins when you start the program!
        stStart()
    End Sub

    Private Sub ThisWorkbook_Shutdown() Handles Me.Shutdown

    End Sub

End Class
