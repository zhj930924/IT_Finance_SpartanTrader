﻿
Public Class TransactionQueue

    Private Sub Sheet5_Startup() Handles Me.Startup

    End Sub

    Private Sub Sheet5_Shutdown() Handles Me.Shutdown

    End Sub

End Class
