﻿
Public Class Environment

    Private Sub Sheet2_Startup() Handles Me.Startup

    End Sub

    Private Sub Sheet2_Shutdown() Handles Me.Shutdown

    End Sub

End Class
